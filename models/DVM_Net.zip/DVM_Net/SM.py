import torch
import torch.nn as nn

from .ShuffleAttention import ShuffleAttention   # 改成相对导入
# from epsanet import PSAModule   # 删除此行

class SM(nn.Module):
    def __init__(self, in_channels):
        super(SM, self).__init__()
        self.in_channel = in_channels

        self.depth_conv1 = nn.Conv2d(
            in_channels=in_channels,
            out_channels=in_channels,
            kernel_size=5,
            stride=2,
            padding=2,
            groups=in_channels
        )
        self.point_conv1 = nn.Conv2d(
            in_channels=in_channels,
            out_channels=in_channels,
            kernel_size=1,
            stride=1,
            padding=0,
            groups=1
        )

        self.depth_conv2 = nn.Conv2d(
            in_channels=in_channels,
            out_channels=in_channels,
            kernel_size=7,
            stride=2,
            padding=1,
            groups=in_channels
        )
        self.point_conv2 = nn.Conv2d(
            in_channels=in_channels,
            out_channels=in_channels,
            kernel_size=1,
            stride=1,
            padding=1,
            groups=1
        )

        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels=in_channels, out_channels=in_channels, kernel_size=5, stride=2, groups=4),
            nn.BatchNorm2d(in_channels, momentum=0.1),
            nn.ReLU()
        )

        self.conv2 = nn.Sequential(
            nn.Conv2d(in_channels=in_channels, out_channels=in_channels, kernel_size=7, stride=2, groups=4),
            nn.BatchNorm2d(in_channels, 0.1),
            nn.ReLU()
        )

        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.conv3 = nn.Sequential(
            nn.Conv2d(in_channels=in_channels, out_channels=in_channels, kernel_size=1),
            nn.BatchNorm2d(in_channels, 0.1),
            nn.ReLU()
        )
        self.BN = nn.BatchNorm2d(in_channels, momentum=0.1)
        self.Re = nn.ReLU(in_channels)
        self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        # self.psa = PSAModule(in_channels, in_channels)   # 删除此行（未使用）
        self.at = ShuffleAttention(channel=in_channels)

    def forward(self, x):
        x1 = x
        x2 = x
        x3 = x

        x1 = self.depth_conv1(x1)
        x1 = self.point_conv1(x1)
        x1 = self.BN(x1)
        x1 = self.Re(x1)

        x2 = self.depth_conv2(x2)
        x2 = self.point_conv2(x2)
        x2 = self.BN(x2)
        x2 = self.Re(x2)

        x3 = self.maxpool(x3)

        x = torch.add(x1, x2)
        x = torch.add(x, x3)
        x = self.conv3(x)
        x = self.up(x)
        x = self.at(x)
        return x